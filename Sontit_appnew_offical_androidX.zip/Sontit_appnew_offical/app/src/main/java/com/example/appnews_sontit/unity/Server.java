package com.example.appnews_sontit.unity;

public class Server {
    public  static  String link  = "https://baomoi.com/";
    public static String linkxxx = "https://mrcong.com/page/";
}
