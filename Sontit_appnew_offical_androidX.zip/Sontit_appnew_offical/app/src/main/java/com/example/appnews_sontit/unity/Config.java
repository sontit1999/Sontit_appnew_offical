package com.example.appnews_sontit.unity;

public class Config {
    public static int orien = 0;
}
